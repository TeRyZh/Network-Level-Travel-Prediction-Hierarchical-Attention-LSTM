import os
import time
import subprocess
import numpy as np

conda_env_name = 'python3.10'  # Replace with your actual environment name
working_directory = r"D:\\Dropbox\\0_Project_Ongoing\\Big Data Application for Travel Time prediction\\Bigscity-LibCity"  # Replace with the actual path

# Activate the conda environment and change working directory
activation_cmd = f"conda activate {conda_env_name} && cd {working_directory}"
subprocess.run(activation_cmd, shell=True, check=True)
# Print the current working directory before execution
print(f"Current working directory before execution: {os.getcwd()}") 

output_windows = [3, 6, 9, 12]
datasets = ["PEMS_BAY", "PEMSD4", "PEMSD8"]
# Calculate the number of experiment IDs needed
num_exp_ids = len(output_windows) * len(datasets)

# Generate a list of experiment IDs as five-digit strings
exp_ids = [f"{i:05d}" for i in np.arange(num_exp_ids)] 

exp_id = 0

for dataset in datasets:
    for ow in output_windows:
        # Load the config file based on exp_id
        config_filename = f"HierAttnLstm_OW_{ow}"

        # Command to run
        cmd = f"python run_model.py --task traffic_state_pred --model HierAttnLstm --dataset {dataset} --config_file {config_filename} --exp_id {exp_ids[exp_id]}"

        # Print the command for clarity
        print(f"Running: {cmd}")

        # Execute the command and capture the output
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

        # Create filename for output (include dataset and exp_id)
        output_filename = f"output_HierAttnLstm_{dataset}_OW_{ow}_exp_{exp_id}.txt"

        # Save the output (stdout and stderr) to the file
        with open(output_filename, "w") as outfile:
            outfile.write(f"Command:\n{cmd}\n\n")
            outfile.write("Standard Output:\n")
            outfile.write(result.stdout)
            outfile.write("\nStandard Error:\n")
            outfile.write(result.stderr)

        print(f"Output saved to {output_filename}")

        # Pause before running the next command (optional)
        time.sleep(5)  # Adjust the sleep time as needed
        exp_id += 1

# python run_all_timesteps.py