import os
import time
import subprocess

Datasets = ["PEMS_BAY", "PEMSD4", "PEMSD8"]
num_layers = [2, 3]
natt_hops = [2, 3]

conda_env_name = 'python3.10'  # Replace with your actual environment name
working_directory = r"D:\\Dropbox\\0_Project_Ongoing\\Big Data Application for Travel Time prediction\\Bigscity-LibCity"  # Replace with the actual path

# Activate the conda environment and change working directory
activation_cmd = f"conda activate {conda_env_name} && cd {working_directory}"
subprocess.run(activation_cmd, shell=True, check=True)
# Print the current working directory before execution
print(f"Current working directory before execution: {os.getcwd()}") 

for Dataset in Datasets:
    
    cmd = f"python run_model.py --task traffic_state_pred --model HierAttnLstm --dataset {Dataset}"

    # Print the command for clarity
    print(f"Running: {cmd}")

    # Execute the command and capture the output
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

    # Create filename for output
    output_filename = f"output_HierAttnLstm_Dataset_{Dataset}.txt"

    # Save the output (stdout and stderr) to the file
    with open(output_filename, "w") as outfile:
        outfile.write(f"Command:\n{cmd}\n\n")
        outfile.write("Standard Output:\n")
        outfile.write(result.stdout)
        outfile.write("\nStandard Error:\n")
        outfile.write(result.stderr)

    print(f"Output saved to {output_filename}")

    # Pause before running the next command (optional)
    time.sleep(5)  # Adjust the sleep time as needed

# Deactivate the conda environment after all runs are complete (optional)
subprocess.run("conda deactivate", shell=True)  
